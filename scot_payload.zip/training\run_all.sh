#!/bin/bash
# run_all.sh
# To be executed ON the TPU node using nohup to prevent dropouts
# Usage: nohup bash ~/scot/training/run_all.sh > ~/scot/run_all.log 2>&1 &

cd ~/scot
source .venv/bin/activate

echo "======================================"
echo "Starting S-CoT SFT Run for Qwen2.5-3B"
echo "======================================"
python training/sft_scot.py > scot_train.log 2>&1
echo "S-CoT Run Finished. Check scot_train.log"

echo "======================================"
echo "Starting Flat SFT Run for Qwen2.5-3B"
echo "======================================"
python training/sft_flat.py > flat_train.log 2>&1
echo "Flat Run Finished. Check flat_train.log"

echo "All training scripts completed."
